package application;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


public class MainController {
	@FXML
	private Label result;
	@FXML
	private Label input;
	
	private float number1=0;
	
	private float number2=0;
	
	private String operator="";
	
	private boolean start=true;
	
	private Calculate calculate=new Calculate();
	
	@FXML
	public void processNumber(ActionEvent event){
		if(start){
			input.setText("");
			start=false;
		}
		String value=((Button)event.getSource()).getText();
		input.setText(input.getText()+ value);
	}
	
	@FXML
	public void processBinaryOperator(ActionEvent event) {
		String value=((Button)event.getSource()).getText();
		if(!value.equals("=")){
			if(!operator.isEmpty())
				return;
			
			operator = value;
			number1=Float.parseFloat(input.getText());			
			input.setText("");
		}else{
			if(operator.isEmpty())
				return;
			
			number2=Float.parseFloat(input.getText());
			float output=calculate.calculateBinaryNumber(number1, number2, operator);
			result.setText(String.valueOf(output));
			operator="";
		}
	}
	public void processUnaryOperator(ActionEvent event) {
	
		String value=((Button)event.getSource()).getText();
		if(!operator.isEmpty())
			return;
		
		operator = value;
		number1=Float.parseFloat(input.getText());	
		input.setText("");
		
		float output=calculate.calculateUnaryNumber(number1,operator);
		result.setText(String.valueOf(output));
		operator="";
	}
	
	public void ClearFunction(ActionEvent event){
		operator="";
		start=true;
		result.setText("");
		input.setText("");
	}
}
